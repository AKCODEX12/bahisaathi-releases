
import 'package:flutter/material.dart';

import '../screens/splash/splash_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../screens/admin/widgets/floating_calculator_overlay.dart';

class BahiSaathiApp extends StatelessWidget {
  const BahiSaathiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BahiSaathi',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),

      builder: (context, child) {
        return StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          initialData: FirebaseAuth.instance.currentUser,
          builder: (context, snapshot) {
            final user = snapshot.data;

            // Login nahi hai to calculator mat dikhao
            if (user == null) {
              return child ?? const SizedBox.shrink();
            }

            // Login ke baad poore app par calculator
            return FloatingCalculatorOverlay(
              child: child ?? const SizedBox.shrink(),
            );
          },
        );
      },

    );
  }
}
