
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';

import '../../firebase_options.dart';
import '../../services/biometric_security_service.dart';
import '../admin/admin_dashboard_screen.dart';
import '../user/user_dashboard_screen.dart';
import '../user/user_login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _checking = true;
  bool _showLockScreen = false;
  bool _navigated = false;
  bool _startupStarted = false;
  bool _nativeSplashRemoved = false;

  String _message = 'Please wait...';

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _startupStarted) return;

      _startupStarted = true;
      _checkStartup();
    });
  }

  // Remove Native Splash only once.
  void _removeNativeSplash() {
    if (_nativeSplashRemoved) return;

    _nativeSplashRemoved = true;
    FlutterNativeSplash.remove();
  }

  // ================= STARTUP CHECK =================

  Future<void> _checkStartup() async {
    if (!mounted || _navigated) return;

    setState(() {
      _checking = true;
      _showLockScreen = false;
      _message = 'Please wait...';
    });

    try {
      // 1. Initialize Firebase.
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      }

      final auth = FirebaseAuth.instance;
      final firestore = FirebaseFirestore.instance;

      // 2. Check logged-in user.
      final user = auth.currentUser;

      if (user == null) {
        await _openUserLogin();
        return;
      }

      final uid = user.uid;
      final email = user.email?.trim().toLowerCase();

      if (email == null || email.isEmpty) {
        await auth.signOut();
        await _openUserLogin();
        return;
      }

      // 3. Verify registered role.
      final roleDoc = await firestore
          .collection('email_roles')
          .doc(email)
          .get();

      if (!roleDoc.exists) {
        await auth.signOut();
        await _openUserLogin();
        return;
      }

      final roleData = roleDoc.data();

      if (roleData == null ||
          roleData['uid'] != uid ||
          roleData['status'] != 'active' ||
          roleData['email'] is! String ||
          (roleData['email'] as String).trim().toLowerCase() != email) {
        await auth.signOut();
        await _openUserLogin();
        return;
      }

      final role = roleData['role'] as String?;

      if (role != 'admin' && role != 'customer') {
        await auth.signOut();
        await _openUserLogin();
        return;
      }

      // 4. Verify actual dashboard account.
      String? customerAdminUid;

      if (role == 'admin') {
        final adminDoc = await firestore
            .collection('admins')
            .doc(uid)
            .get();

        final adminData = adminDoc.data();

        if (!adminDoc.exists ||
            adminData == null ||
            adminData['uid'] != uid ||
            adminData['role'] != 'admin' ||
            adminData['email'] is! String ||
            (adminData['email'] as String).trim().toLowerCase() != email) {
          await auth.signOut();
          await _openUserLogin();
          return;
        }
      } else {
        // Get Admin selected during Customer Login.
        customerAdminUid =
        await BiometricSecurityService.getCustomerAdmin(
          customerUid: uid,
        );

        if (customerAdminUid == null ||
            customerAdminUid.trim().isEmpty) {
          await auth.signOut();
          await _openUserLogin();
          return;
        }

        // Verify Customer-Admin relationship.
        final relationship = await firestore
            .collection('admin_customers')
            .where('customerUid', isEqualTo: uid)
            .where('adminUid', isEqualTo: customerAdminUid)
            .where('active', isEqualTo: true)
            .limit(1)
            .get();

        if (relationship.docs.isEmpty) {
          await auth.signOut();
          await _openUserLogin();
          return;
        }
      }

      // 5. Check App Lock setting.
      final biometricEnabled =
      await BiometricSecurityService.isEnabled(
        role: role!,
        uid: uid,
      );

      if (!mounted || _navigated) return;

      // 6. App Lock verification.
      if (biometricEnabled) {
        // Remove Native Splash before showing the lock screen.
        _removeNativeSplash();

        setState(() {
          _showLockScreen = true;
          _checking = true;
          _message = 'Authenticate to open BahiSaathi';
        });

        final authenticated =
        await BiometricSecurityService.authenticate();

        if (!mounted || _navigated) return;

        if (!authenticated) {
          await _showLockedMessage(
            'Authentication was not completed. Please try again.',
          );
          return;
        }
      }

      // 7. Open Dashboard.
      if (role == 'admin') {
        await _openAdminDashboard();
      } else {
        await _openCustomerDashboard(
          uid: uid,
          email: email,
          adminUid: customerAdminUid!,
        );
      }
    } catch (e) {
      debugPrint('STARTUP ERROR: $e');

      await _showLockedMessage(
        'Unable to verify your account. Check your internet and try again.',
      );
    }
  }

  // ================= ADMIN DASHBOARD =================

  Future<void> _openAdminDashboard() async {
    if (!mounted || _navigated) return;

    _removeNativeSplash();
    _navigated = true;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => const AdminDashboardScreen(),
      ),
          (route) => false,
    );
  }

  // ================= CUSTOMER DASHBOARD =================

  Future<void> _openCustomerDashboard({
    required String uid,
    required String email,
    required String adminUid,
  }) async {
    if (!mounted || _navigated) return;

    _removeNativeSplash();
    _navigated = true;

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => UserDashboardScreen(
          customerUid: uid,
          customerEmail: email,
          adminUid: adminUid,
        ),
      ),
          (route) => false,
    );
  }

  // ================= USER LOGIN =================

  Future<void> _openUserLogin() async {
    if (!mounted || _navigated) return;

    _removeNativeSplash();
    _navigated = true;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const UserLoginScreen(),
      ),
    );
  }

  // ================= LOCK SCREEN MESSAGE =================

  Future<void> _showLockedMessage(String message) async {
    if (!mounted) return;

    _removeNativeSplash();

    setState(() {
      _checking = false;
      _showLockScreen = true;
      _message = message;
    });
  }

  // ================= LOGOUT =================

  Future<void> _logout() async {
    try {
      await FirebaseAuth.instance.signOut();

      if (!mounted) return;

      await _openUserLogin();
    } catch (e) {
      debugPrint('BIOMETRIC LOGOUT ERROR: $e');

      await _showLockedMessage(
        'Unable to logout. Please try again.',
      );
    }
  }

  // ================= LOCK SCREEN UI =================

  Widget _buildLockScreen() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.lock_outline,
                  size: 75,
                  color: Colors.green,
                ),

                const SizedBox(height: 20),

                const Text(
                  'BahiSaathi Locked',
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 15),

                Text(
                  _message,
                  textAlign: TextAlign.center,
                ),

                if (_checking) ...[
                  const SizedBox(height: 25),
                  const CircularProgressIndicator(),
                ],

                const SizedBox(height: 30),

                if (!_checking)
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: _checkStartup,
                      icon: const Icon(Icons.fingerprint),
                      label: const Text('Try Again'),
                    ),
                  ),

                const SizedBox(height: 12),

                if (!_checking)
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: OutlinedButton.icon(
                      onPressed: _logout,
                      icon: const Icon(Icons.logout),
                      label: const Text('Logout'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ================= BUILD =================

  @override
  Widget build(BuildContext context) {
    if (_showLockScreen) {
      return _buildLockScreen();
    }

    // No custom Flutter Splash UI.
    // Native Splash stays visible while startup checks run.
    return const Scaffold(
      backgroundColor: Colors.white,
    );
  }
}
